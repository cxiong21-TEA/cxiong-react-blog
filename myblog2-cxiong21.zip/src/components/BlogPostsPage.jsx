
import BlogPost from "./BlogPost";

function BlogPostsPage({ posts }) {
  return (
    <div>
      <h1>All Blog Posts</h1>

      {posts.map((post) => (
        <BlogPost
          key={post.id}
          id={post.id}
          title={post.title}
          content={post.content}
          author={post.author}
          date={post.date}
        />
      ))}
    </div>
  );
}

export default BlogPostsPage;
