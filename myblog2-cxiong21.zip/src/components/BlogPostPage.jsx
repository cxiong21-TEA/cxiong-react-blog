
import { useParams, Link } from "react-router";
import BlogPost from "./BlogPost";

function BlogPostPage({ posts }) {
  const { id } = useParams();

  const post = posts.find(
    (post) => String(post.id) === id
  );

  if (!post) {
    return <h2>Blog post lost!</h2>;
  }

  return (
    <div className="return-home">
      <Link to="/blog" className="return-home-link">
        Return
      </Link> 

      <BlogPost
        id={post.id}
        title={post.title}
        content={post.fullcontent}
        author={post.author}
        date={post.date}
      />
    </div>
  );
}

export default BlogPostPage;
