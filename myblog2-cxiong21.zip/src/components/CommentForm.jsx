/* Referencing useState Video 8.2_useState from Module 10 */

import React, { useState, useEffect } from "react";

function CommentForm({ postId }) {
    const [name, setName] = useState("");
    const [comment, setComment] = useState("");
    const [comments, setComments] = useState("");
    
    const addComment = () => {
        setComments([...comments, { name, comment }]);
        setName("");
        setComment("");
    };

    return (
    <div className="comment-form">
        <h1>Comments</h1>
            <h2 className ="text-2xl font-bold mb-3 text-gray-800">
                Add a Comment</h2>
            <textarea
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            />
            <textarea
            type="text"
            placeholder="Comment"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            />
            <button onClick={addComment}>Submit</button>
                {comments.length === 0 ? (
                    <>
                        <p>No comments yet.</p>
                        <p>Be the first to comment.</p>
                    </>
                ) : (
                    <ul>
                        {comments.map((c, index) => (
                            <li key={index}>{c.name}: {c.comment}</li>
                        ))}
                    </ul>
                )}
        </div>
    );
}

export default CommentForm;
